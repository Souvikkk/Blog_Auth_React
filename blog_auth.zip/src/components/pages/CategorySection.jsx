import React, { useEffect, useState } from "react";
import { GetCategoryList, GetRecentPost } from "../Service/AllApi";
import { toast } from "react-toastify";
import {
  Box,
  Grid,
  Paper,
  Skeleton,
  TextField,
  Typography,
} from "@mui/material";
import { Link } from "react-router-dom";
import { CircleLoader } from "react-spinners";

import { useSearch } from "../Contex/SearchContex";

const CategorySection = () => {
  const [allCat, setAllCat] = useState([]);
  const [allRecentPosts, setAllRecentPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadingSpinner, setLoadingSpinner] = useState(true);

  const { searchQuery, setSearchQuery } = useSearch();
  const GetCategory = async () => {
    try {
      const response = await GetCategoryList();
      setAllCat(response?.data?.data);
      setLoading(false);
    } catch (error) {
      toast.error("something went worng");
    }
  };
  const GetRecent = async () => {
    try {
      const response = await GetRecentPost();
      setAllRecentPosts(response?.data?.data);
      setLoadingSpinner(false);
    } catch (error) {
      toast.error("something went wrong");
    }
  };

  useEffect(() => {
    GetCategory();
    GetRecent();
  }, []);

  const filteredCategories = allCat.filter((value) =>
  value.category.toLowerCase().includes(searchQuery.toLowerCase())
);

const filteredRecentPosts = allRecentPosts.filter((item) =>
  item.title.toLowerCase().includes(searchQuery.toLowerCase())
);
console.log("Search Query (CategorySection):", searchQuery);
console.log("Filtered Categories:", filteredCategories);
console.log("Filtered Recent Posts:", filteredRecentPosts);
  return (
    <>
      {loading ? (
        <Paper
          elevation={10}
          sx={{
            padding: "10px",
            borderRadius: "30px",
            backgroundColor: "#dfedf5",
          }}
        >
          <Box
            style={{ marginBottom: "10px", marginLeft: "35px", height: "40px" }}
          >
            <Skeleton variant="rectangular" height={40} animation="wave" />
          </Box>

          <Box
            style={{
              marginLeft: "35px",
              marginY: "10px",
              fontWeight: "bold",
              height: "20px",
            }}
          >
            <Skeleton variant="text" height={20} animation="wave" />
          </Box>

          <ul>
            {Array.from({ length: 5 }).map((_, index) => (
              <Box key={index} style={{ marginBottom: "10px", height: "20px" }}>
                <Skeleton variant="text" height={20} animation="wave" />
              </Box>
            ))}
          </ul>

          <Box
            style={{
              marginLeft: "35px",
              marginY: "10px",
              fontWeight: "bold",
              height: "20px",
            }}
          >
            <Skeleton variant="text" height={20} animation="wave" />
          </Box>

          <Grid>
            {Array.from({ length: 5 }).map((_, index) => (
              <Box
                key={index}
                style={{
                  display: "flex",
                  padding: "10px",
                  marginLeft: "30px",
                  marginY: "10px",
                }}
              >
                <Box style={{ width: "55px", height: "30px" }}>
                  <Skeleton
                    variant="rectangular"
                    height={30}
                    width={55}
                    animation="wave"
                  />
                </Box>
                <Box
                  style={{ marginLeft: "10px", height: "40px", width: "150px" }}
                >
                  <Skeleton variant="text" height={20} animation="wave" />
                  <Skeleton variant="text" height={20} animation="wave" />
                </Box>
              </Box>
            ))}
          </Grid>
        </Paper>
      ) : (
        <Paper
          elevation={10}
          sx={{
            padding: "10px",
            backgroundColor: "#dfedf5",
            borderRadius: "30px",
          }}
        >
          <TextField
            sx={{ margin: "20px 0px", marginLeft: "35px" }}
            label="Search"
            variant="outlined"
            placeholder="search"
            value={searchQuery}
            onChange={e=>setSearchQuery(e.target.value)}
          />
          {/* <Search/> */}
          <br />
          <Typography
            variant="p"
            sx={{ marginLeft: "35px", marginY: "10px", fontWeight: "bold" }}
          >
            Categories{" "}
          </Typography>
          <ul>
            {filteredCategories?.map((value, index) => {
              return (
                <>
                  <Link 
                    to={`/categorydetails/${value._id}`}
                    style={{ textDecoration: "none" }}
                  >
                    <li
                      key={index}
                      style={{
                        listStyle: "none",
                        marginBottom: "10px",
                        color: "black",
                      }}
                    >
                      {" "}
                      {value.category} <span style={{fontSize:'14px'}}>({value.category.length})</span>
                    </li>{" "}
                  </Link>
                </>
              );
            })}
          </ul>
          <Typography
            variant="p"
            sx={{ marginLeft: "35px", marginY: "10px", fontWeight: "bold" }}
          >
            Recent Posts{" "}
          </Typography>
          <Grid>
            {loadingSpinner ? (
              <Box sx={{ paddingLeft: "40px" }}>
                {" "}
                <CircleLoader color="#36d7b7" />{" "}
              </Box>
            ) : (
              <Grid item xs={12} sm={12} md={12}>
                {filteredRecentPosts?.map((items, index) => {
                  return (
                    <>
                      {}
                      <Grid
                        sx={{
                          display: "flex",
                          padding: "10px",
                          marginLeft: "30px",
                          marginY: "10px",
                        }}
                      >
                        <img
                          src={`https://restapinodejs.onrender.com/api/blog/image/${items._id}`}
                          alt=""
                          width={"55px"}
                          height={"30px"}
                          style={{ borderRadius: "20px" }}
                        />
                        <Link
                          to={`/recentPostDetails/${items._id}`}
                          style={{ textDecoration: "none" }}
                        >
                          <li
                            key={index}
                            style={{ listStyle: "none", marginBottom: "0px" }}
                          >
                            {" "}
                            <Typography
                              fontSize={"12px"}
                              fontWeight={"bold"}
                              marginLeft={"10px"}
                              color={"black"}
                            >
                              {items.title} <br />
                              <span style={{ fontSize: "8px" }}>
                                <time dateTime="01-01-2023">
                                  {new Date(
                                    items.createdAt
                                  ).toLocaleDateString()}{" "}
                                </time>{" "}
                              </span>{" "}
                            </Typography>{" "}
                          </li>{" "}
                        </Link>
                      </Grid>
                    </>
                  );
                })}
              </Grid>
            )}
          </Grid>
        </Paper>
      )}
    </>
  );
};

export default CategorySection;
