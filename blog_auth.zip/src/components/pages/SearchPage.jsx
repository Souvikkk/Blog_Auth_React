import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom';
import { useAuth } from '../Contex/AuthContext';
import { GetAllBlog } from '../Service/AllApi';

const SearchPage = () => {
  const { encodedItem } = useParams();
  const searchItem=decodeURIComponent(encodedItem)
  const [blog,setBlog] = useState([])
  const [loading,setLoading] = useState(true)

  const imgUrl ="https://restapinodejs.onrender.com"
  const [auth] = useAuth()
  const getBlog = async()=>{
    const response = await GetAllBlog()
    setBlog(response?.data?.data)
    setLoading(false)
  }
useEffect(()=>{
  getBlog()
},[])

const result = blog.filter((blogs)=>{
  const searchItemLower = searchItem.toLowerCase();
  const titleLower = blogs.title.toLowerCase()
  const categoryLower = blogs.category.toLowerCase()
  const text = blogs.postText.replace(/<[^>]*>/g, "");
  const textLower = text.toLowerCase();

  return (
    titleLower.includes(searchItemLower) ||
    categoryLower.includes(searchItemLower) ||
    textLower.includes(searchItemLower)
  );
  
})
  
console.log("res", result);

  return (
    <>


    </>
  )
}

export default SearchPage